package com.example.myfirstapp.todolist.Home.Adapter

import android.app.Activity
import android.app.AppComponentFactory
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.myfirstapp.todolist.Home.Home
import com.example.myfirstapp.todolist.Home.Model.Note
import com.example.myfirstapp.todolist.MainActivity
import com.example.myfirstapp.todolist.R
import com.example.myfirstapp.todolist.note.DB.DB_note
import com.example.myfirstapp.todolist.note.note
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.note_item.view.*
import java.security.AccessController.getContext
import java.util.*


class NoteAdapter( var click : onClick  , var c: Context?, var list: ArrayList<Note>, var home: Home)  : RecyclerView.Adapter<NoteAdapter.MyAdapter>() {

    inner class MyAdapter(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title = itemView.titleNote
        var desc = itemView.desc
        var  a = itemView.clicking
        var checkbox = itemView.checkBox
        var delet = home.deletenots
        var actualItem = itemView.itemClicking



    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter {
        var root = LayoutInflater.from(c).inflate(R.layout.note_item, parent, false)
        return MyAdapter(root)
    }

    override fun onBindViewHolder(holder: MyAdapter, position: Int) {
        holder.title.text = list[position].title

        if ( holder.title.text.toString().length > 10){
            holder.title.text = "${ holder.title.text.substring(0, 10)} ..."
        }
        holder.desc.text = list[position].desc
        holder.a.setOnLongClickListener {
            holder.checkbox.isVisible = true
           holder.delet.isVisible = true
            list[position].ischeck = false
            holder.checkbox.isChecked = false

 //     Toast.makeText(c, "ddddddddddddddd", Toast.LENGTH_LONG).show()
             true
        }
        holder.delet.setOnClickListener {
          //      Toast.makeText(c, i.ischeck.toString(), Toast.LENGTH_LONG).show()
                    var array = DB_note(c).getAllNotes()
                    for ( ii in array ){
                        list.removeAt(position)
                        DB_note(c).deleteNoteFromDB(ii.id)
                        notifyDataSetChanged()
                    }

                }

        holder.actualItem.setOnClickListener {
            click.onClick(position)
        }

    }
    interface onClick {
        fun onClick( p : Int ){

        }

    }


    override fun getItemCount(): Int {
        return list.size
    }

}







