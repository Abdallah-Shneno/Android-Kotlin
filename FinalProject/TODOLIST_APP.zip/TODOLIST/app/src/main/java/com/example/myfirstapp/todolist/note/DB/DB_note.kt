package com.example.myfirstapp.todolist.note.DB

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.myfirstapp.todolist.Home.Model.Note
import com.example.myfirstapp.todolist.note.note
import com.google.android.material.timepicker.TimeFormat
import java.sql.Time
import java.sql.Timestamp

class DB_note(context: Context?) : SQLiteOpenHelper(context, dataBaseName, null, database_version) {
    companion object {
        const val dataBaseName = "Nots_DataBase"
        const val database_version = 1
    }

    private var dp: SQLiteDatabase

    init {
        dp = this.writableDatabase
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // here you can create your tables in this database ade its perform only one time
        db!!.execSQL(Note.create_table_note)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // you want delete here table after create it again
        //   db!!.execSQL("drop table if exists ${Note.table_name}")
    }

    fun addNewNote(title: String, desc: String): Boolean {
        val r = ContentValues()
        r.put("${Note.coll_title}", title)
        r.put("${Note.coll_desc}", desc)
        return dp.insert(Note.table_name, null, r) > 0
    }

    fun getAllNotes(): ArrayList<Note> {
        var notes = ArrayList<Note>()
        // as select
        var cersor = dp.rawQuery("select * from ${Note.table_name}", null)
        cersor.moveToFirst()
        while (! cersor.isAfterLast) { // arrive to the lase point
            //  var row0 = cersor.getInt(0)
            //  var time = cersor.getString(3)
            //  var time = cersor.getString(cersor.getColumnName(Note.coll_time))
            val n = Note(cersor.getInt(0), cersor.getString(1), cersor.getString(2))
            notes.add(n)
            cersor.moveToNext()
        }
        cersor.close()
        return notes
    }
    fun deleteNoteFromDB ( id : Int) : Boolean{
        return dp.delete(Note.table_name , "$id = ${Note.coll_id}" , null ) > 0
    }
    fun updateNote ( id : Int , title: String , desc: String) : Boolean {
        val r = ContentValues()
        r.put("${Note.coll_title}", title)
        r.put("${Note.coll_desc}", desc)
        return dp.update(Note.table_name , r , "$id == ${Note.coll_id}" , null) > 0
    }
}



