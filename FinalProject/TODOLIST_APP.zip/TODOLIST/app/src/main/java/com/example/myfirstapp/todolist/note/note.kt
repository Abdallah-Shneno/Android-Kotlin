package com.example.myfirstapp.todolist.note

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.ActivityNavigator
import com.example.myfirstapp.todolist.Home.Home
import com.example.myfirstapp.todolist.MainActivity
import com.example.myfirstapp.todolist.R
import com.example.myfirstapp.todolist.note.DB.DB_note
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_note.*
import kotlinx.android.synthetic.main.fragment_note.view.*
import kotlinx.android.synthetic.main.note_item.view.*
import kotlinx.android.synthetic.main.toolbar.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [note.newInstance] factory method to
 * create an instance of this fragment.
 */
class note : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var a =  inflater.inflate(R.layout.fragment_note, container, false)
        // number of word
        (activity as AppCompatActivity?)!!.supportActionBar!!.hide()

        a.writtenText.addTextChangedListener (object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                val trimmedStr = s.toString().trim()
                if (trimmedStr.isEmpty()) {
                    a.result.text = "0 word"
                } else {
                    if ( trimmedStr.split("\\s+".toRegex()).size == 1 )
                        a.result.text = trimmedStr.split("\\s+".toRegex()).size.toString()+" word"
                    else
                        a.result.text = trimmedStr.split("\\s+".toRegex()).size.toString()+" words"

                }

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {

            }
        })
        var dababse = DB_note(context)
        a.back.setOnClickListener {  goToHome() }
        a.save.setOnClickListener {
            dababse.addNewNote(a.title_of_note.text.toString(), a.writtenText.text.toString())
            goToHome() }

        return a
    }

    fun goToHome() {
        activity?.startActivity(Intent(context,MainActivity::class.java))
     }

}



