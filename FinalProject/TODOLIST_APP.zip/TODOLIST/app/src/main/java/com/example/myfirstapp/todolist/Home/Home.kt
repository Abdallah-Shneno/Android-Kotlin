package com.example.myfirstapp.todolist.Home

import android.accounts.Account
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.myfirstapp.todolist.Contact_Us.Contact_us
import com.example.myfirstapp.todolist.Home.Adapter.NoteAdapter
import com.example.myfirstapp.todolist.MainActivity
import com.example.myfirstapp.todolist.R
import com.example.myfirstapp.todolist.note.DB.DB_note
import com.example.myfirstapp.todolist.note.note
import kotlinx.android.synthetic.main.fragment_home.view.*
import kotlinx.android.synthetic.main.note_item.*
import kotlinx.android.synthetic.main.note_item.view.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class Home() : Fragment() ,  NoteAdapter.onClick{

    lateinit var n : note
    lateinit var v : View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



    }

    override fun onCreateView (
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var a = inflater.inflate(R.layout.fragment_home, container, false)
        n = note()
        a.add_note.setOnClickListener {
            replaceFragment(n)
        }
        // DB
        var d = DB_note(activity?.applicationContext)
//         var result = d.addNewNote("new thing added" ,"sucsessfully")

        // adapter
        var date = d.getAllNotes()
//        date.add(Note(1, "hello", "ethod is called to notify you that, somewhere within s, the text has been changed. It is legitimate to make further changes to s from this callback, but be careful not to get yourself into an infinite loop, because any changes you make will cause this method to be ca"))
//        date.add(Note(1, "hello", "ethod is called to notify you that, somewhere within s, the text has been changed. It is legitimate to make further changes to s from this callback, but be careful not to get yourself into an infinite loop, because any changes you make will cause this method to be ca"))
//        date.add(Note(1, "hello", "hello"))
//        date.add(Note(1, "hello", "ethod is called to notify you that, somewhere within s, the text has been changed. It is legitimate to make further changes to s from this callback, but be careful not to get yourself into an infinite loop, because any changes you make will cause this method to be ca"))
//        date.add(Note(1, "asdasdsadsads asdsad ", "hello"))
//        date.add(Note(1, "heas dsad asdllo", "aasd sad asdasdasdas a das dasd sad as dsaethod is called to notify you that, somewhere within s, the text has been changed. It is legitimate to make further changes to s from this callback, but be careful not to get yourself into an infinite loop, because any changes you make will cause this method to be ca"))
//        date.add(Note(1, "he dsadsad llo", "ethod is called to notify you that, somewhere within s, the text has been changed. It is legitimate to make further changes to s from this callback, but be careful not to get yourself into an infinite loop, because any changes you make will cause this method to be ca"))
//        date.add(Note(1, "hesa dsa dsallo", "hello"))
//        date.add(Note(1, "hela sdsassas as das dsad asd asd  aaslo", "ethod is called to notify you that, somewhere within s, the text has been changed. It is legitimate to make further changes to s from this callback, but be careful not to get yourself into an infinite loop, because any changes you make will cause this method to be ca"))
        var g = NoteAdapter( this , activity?.applicationContext , date , this)
     //   var adapter = context?.let { NoteAdapter(it, date , this) }
          var adapter = g


        a.recyclerNotes.layoutManager = GridLayoutManager(context, 2)
        a.recyclerNotes.adapter = adapter
        super.onCreate(savedInstanceState)
        activity?.onBackPressedDispatcher?.addCallback( viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

        //        Toast.makeText(context, "finish ....", Toast.LENGTH_LONG).show()

                replaceFragment(Home())
            //     activity?.startActivity(Intent(context, MainActivity::class.java))
          //      activity!!.finish()
            }
        })


        return a

    }


    override fun onClick(p: Int) {
           replaceFragment(n)
       }





    fun replaceFragment(f: Fragment) {
        var fragmentTransaction = activity?.supportFragmentManager?.beginTransaction()
        fragmentTransaction!!.replace(R.id.navigation, f)
        fragmentTransaction.commit()
    }






}





