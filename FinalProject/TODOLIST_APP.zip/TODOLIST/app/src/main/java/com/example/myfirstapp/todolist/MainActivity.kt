package com.example.myfirstapp.todolist

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import com.example.myfirstapp.todolist.Account.Account
import com.example.myfirstapp.todolist.Contact_Us.Contact_us
import com.example.myfirstapp.todolist.Home.Home
import com.example.myfirstapp.todolist.Setting.Setting
import com.example.myfirstapp.todolist.Trush.Trush
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.header.view.*
import kotlinx.android.synthetic.main.toolbar.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle


class MainActivity() : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor =
                    ContextCompat.getColor(applicationContext, R.color.statusBarColor)
//            supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#ff75a0")))
        }
        setDate()

        //  supportActionBar?.hide()
        setSupportActionBar(toolbar)
        var toggel = ActionBarDrawerToggle(this, drawer_layout, toolbar, 0, 0)
        drawer_layout.addDrawerListener(toggel)
        toggel.syncState()
        navigation_view.setNavigationItemSelectedListener(this)
        addFragment(Home())





    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        var id = item.itemId
        when (id) {
            R.id.navhome -> replaceFragment(Home())
            R.id.navsetting -> replaceFragment(Setting())
            R.id.navtrush -> replaceFragment(Trush())
            R.id.navcontact_us -> replaceFragment(Contact_us())
            R.id.navAccount -> replaceFragment(Account())
        }
        drawer_layout.closeDrawer(GravityCompat.START)
        return true
    }


    fun addFragment(f: Fragment) {
        var fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.add(R.id.navigation, f)
        fragmentTransaction.commit()
    }


    fun replaceFragment(f: Fragment) {
        var fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.navigation, f)
        fragmentTransaction.commit()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun setDate() {
        var d = LocalDate.now().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)).toString()
        var t = LocalTime.now().format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)).toString()
        val navigationView = navigation_view as NavigationView
        val hView: View = navigationView.getHeaderView(0)
        if (t.contains("AM")
        ) {
            hView.headerid.imgeTime.setImageResource(R.drawable.ic_moona)
        } else
            hView.headerid.imgeTime.setImageResource(R.drawable.ic_sun) // sun here
        hView.headerid.dateNaw.text = d
        hView.headerid.timeNow.text = t


    }


}


