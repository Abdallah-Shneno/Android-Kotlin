package com.example.myfirstapp.todolist.Home.Model

data class Note ( var id : Int , var title : String , var desc : String) {
    var ischeck = false
    companion object{
        const val table_name  : String =  "note"
        const val coll_id  : String =  "_id"
        const val coll_title  : String =  "title"
        const val coll_desc  : String =  "desc"
        const val create_table_note  : String =  "" +
                "create table $table_name (" +
                "$coll_id integer primary key autoincrement ," +
                "$coll_title varchar(50)," +
                "$coll_desc varchar(1000) )"




    }
}
